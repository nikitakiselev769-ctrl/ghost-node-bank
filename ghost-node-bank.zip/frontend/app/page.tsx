'use client'

import { motion } from 'framer-motion'

export default function HomePage() {
  return (
    <main className="min-h-screen bg-black text-white overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-red-900/20 via-black to-emerald-900/20 blur-3xl" />

      <section className="relative z-10 flex flex-col items-center justify-center min-h-screen text-center px-6">
        <motion.h1
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-7xl font-bold tracking-tight"
        >
          Ghost Node Bank
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="mt-6 text-zinc-400 text-xl"
        >
          The Network Behind Your Wealth.
        </motion.p>

        <div className="flex gap-4 mt-10">
          <button className="px-8 py-4 rounded-2xl bg-red-600 hover:bg-red-500 transition">
            Create Account
          </button>

          <button className="px-8 py-4 rounded-2xl border border-zinc-700 backdrop-blur-xl">
            Enter The Network
          </button>
        </div>
      </section>
    </main>
  )
}