'use client'

export default function DashboardPage() {
  return (
    <main className="min-h-screen bg-[#050505] text-white p-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        <div className="lg:col-span-2 rounded-3xl bg-white/5 border border-white/10 p-8 backdrop-blur-2xl">
          <h2 className="text-3xl font-bold">
            Общий баланс
          </h2>

          <div className="mt-6 text-6xl font-black">
            $24,850
          </div>
        </div>

        <div className="rounded-3xl bg-gradient-to-br from-red-900 to-black p-8 border border-red-500/20">
          <h3 className="text-xl font-semibold">
            NODE AI
          </h3>

          <p className="mt-4 text-zinc-300">
            Вы потратили на 18% больше на развлечения.
          </p>
        </div>
      </div>
    </main>
  )
}