import { Request, Response } from 'express'
import { PrismaClient } from '@prisma/client'
import {
  generateCardNumber,
  generateCVV
} from '../utils/cardGenerator'

const prisma = new PrismaClient()

export const createCard = async (
  req: Request,
  res: Response
) => {
  const userId = (req as any).user.id

  const { tier } = req.body

  const card = await prisma.card.create({
    data: {
      userId,
      tier,
      cardNumber: generateCardNumber(),
      cvv: generateCVV(),
      expiry: '12/30',
      balance: 1000
    }
  })

  return res.json(card)
}