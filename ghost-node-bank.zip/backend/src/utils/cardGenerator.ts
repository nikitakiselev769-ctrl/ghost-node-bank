export const generateCardNumber = () => {
  return '5227 ' + Math.floor(Math.random() * 10000)
    .toString()
    .padStart(4, '0') + ' ' +
    Math.floor(Math.random() * 10000)
      .toString()
      .padStart(4, '0') + ' ' +
    Math.floor(Math.random() * 10000)
      .toString()
      .padStart(4, '0')
}

export const generateCVV = () => {
  return Math.floor(100 + Math.random() * 900).toString()
}