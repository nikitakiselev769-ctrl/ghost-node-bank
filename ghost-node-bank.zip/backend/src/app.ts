import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import morgan from 'morgan'
import rateLimit from 'express-rate-limit'

import authRoutes from './routes/auth.routes'
import cardRoutes from './routes/card.routes'
import transactionRoutes from './routes/transaction.routes'

const app = express()

app.use(cors())
app.use(helmet())
app.use(express.json())
app.use(morgan('dev'))

app.use(rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100
}))

app.use('/api/auth', authRoutes)
app.use('/api/cards', cardRoutes)
app.use('/api/transactions', transactionRoutes)

export default app