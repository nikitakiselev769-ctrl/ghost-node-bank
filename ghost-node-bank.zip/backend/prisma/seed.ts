import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcrypt'

const prisma = new PrismaClient()

async function main() {
  const password = await bcrypt.hash('ghost123', 10)

  await prisma.user.create({
    data: {
      email: 'admin@ghostnode.bank',
      password,
      fullName: 'Ghost Admin',
      balance: 100000
    }
  })
}

main()